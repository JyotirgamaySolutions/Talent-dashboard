<!DOCTYPE html>
<html lang="en">
<head>
  <title>Employee Task Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/bootstrap.theme.min.css">
  <link rel="stylesheet" href="./assets/bootstrap-datepicker/css/datepicker.css">
  <link rel="stylesheet" href="./assets/bootstrap-datepicker/css/datepicker-custom.css">
  <link rel="stylesheet" href="./assets/css/custom.css">
  <style>
  .navbar-brand {
    font-size: 20px;
    font-weight: bold;
    color: #E65200; /* Default color */
    
  }

  .navbar-brand:hover {
    color: orange !important; /* Hover color */
  }

  .navbar-center {
    display: flex;
    justify-content: center;
    width: 100%;
    color: blue;
  }

   .navbar-nav-custom {
    width: 100%;
  }

  .navbar-nav-custom {
    width: 100%;
    padding: 0;
}


/* Sidebar Styling */
nav.sidebar {
    width: 250px;
    height: 100%;
    background-color: #F8F8F8; /* Dark gray */
    color: black;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1000;
    overflow-y: auto;
    
}
/* Style each menu item like a button */
.navbar-nav-custom li {
    list-style: none;
    margin: 5px 0;
}



/* Add a hover effect */
.navbar-nav-custom li a:hover {
    background:#F8F8F8;
    transform: translateY(-2px);
    box-shadow: 3px 3px 8px rgba(0, 0, 0, 0.3);
    color: orange;
}

/* Highlight active menu item */
.navbar-nav-custom li.active a {
    background: #F8F8F8;
    color: orange;
    transform: scale(1.05);
}

/* Adjust icon spacing */
.navbar-nav-custom li a .glyphicon {
    margin-left: 10px;
    font-size: 18px;
    color: white;
}
	   body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      width: 250px;
      background: #fff;
      box-shadow: 2px 0 5px rgba(0,0,0,0.1);
      padding: 20px 15px;
    }

    .sidebar h4 {
      font-weight: bold;
      color: #E65200;
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: #333;
      text-decoration: none;
      margin: 15px 0;
    }

   html, body {
  height: 100%;
  margin: 0;
  padding: 0;
}



.main {
  margin-left: 260px; /* sidebar width */
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.main-content {
  width: 100%;
  height: 100%;
  background: white;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
  padding: 20px;
  overflow: auto;
}

</style>
<link rel="stylesheet" href="custom.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">



  <script src="./assets/js/jquery.min.js"></script>
  <script src="./assets/js/bootstrap.min.js"></script>
  <script src="./assets/js/custom.js"></script>
  <script src="./assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script src="./assets/bootstrap-datepicker/js/datepicker-custom.js"></script>
  <script type="text/javascript">
    
    /* delete function confirmation  */
    function check_delete() {
      var check = confirm('Are you sure you want to delete this?');
        if (check) {
         
            return true;
        } else {
            return false;
      }
    }
  </script>
</head>
<body>

<nav class="navbar navbar-inverse sidebar navbar-fixed-top" role="navigation">
    <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
       
  <div class="container-fluid">
    <div class="navbar-center">
      <a class="navbar-brand" href="task-info.php" style="color: #E65200;">
        <?php echo $_SESSION['name']; ?>
      </a>
    </div>
  </div>


		<!-- Bliss Stewards' Assigned Services Section -->



    </div>

    <?php
    $user_role = $_SESSION['user_role'];
     if($user_role == 1){
    ?>
      <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-nav-custom" >
		      <li <?php if($page_name == "Attendance" ){echo "class=\"active\"";} ?>><a href="attendance-info.php" style="background-color: #F8F8F8; color: #E65200;"><i class="fa fa-calendar" aria-hidden="true"></i>Attendance </a></li>
		  
       <li <?php if($page_name == "Task_Info"){ echo 'class="active"'; } ?>>
    <a href="task-info.php" style="background-color: #F8F8F8; color: #E65200;">
        <i class="fa fa-laptop"></i> Task Management
    </a>
</li>

    
        <li <?php if($page_name == "Admin" ){echo "class=\"active\"";} ?>><a href="manage-admin.php" style="background-color: #F8F8F8; color: #E65200;"><i class="fa fa-user" aria-hidden="true"></i>Administration</a></li>
        




        <li <?php if($page_name == "Daily-Attennce-Report" ){echo "class=\"active\"";} ?>><a href="daily-attendance-report.php" style="background-color: #F8F8F8; color: #E65200;"><i class="fa fa-id-card" aria-hidden="true"></i>Attendance Report</a></li>
		    
		  
        <li ><a href="?logout=logout" style="background-color: #F8F8F8; color: #E65200;"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a></li>
      </ul>
    </div>
    <?php 
     }else if($user_role == 2){

      ?>
          <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-nav-custom">
		   <li <?php if($page_name == "Attendance" ){echo "class=\"active\"";} ?>><a href="attendance-info.php" style="background-color: #F8F8F8; color: #E65200;"><i class="fa fa-calendar" aria-hidden="true"></i>Attendance </a></li>
		  
        <li <?php if($page_name == "Task_Info" ){echo "class=\"active\"";} ?>><a href="task-info.php" style="background-color: #F8F8F8; color: #E65200;">
        <i class="fa fa-laptop"></i> Task Management
    </a></li>
       
		 
        <li ><a href="?logout=logout" style="background-color: #F8F8F8; color: #E65200;"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a></li>
      </ul>
    </div>

      <?php

     }else{
       header('Location: index.php');
     }

    ?>
    


  </div>
</nav>



<div class="main">

